
jQuery( document ).ready(function($) {
$('#teacher').slick({
dots: false,
arrows: true,
infinite: true,
speed: 2000,
slidesToShow: 3,
loop: true,
slidesToScroll: 1,
autoplay: false,
autoplaySpeed: 2000,
pauseOnHover: false,
});
});




jQuery( document ).ready(function($) {
$('#classes').slick({
dots: false,
arrows: true,
infinite: true,
speed: 2000,
slidesToShow: 4,
loop: true,
slidesToScroll: 1,
autoplay: false,
autoplaySpeed: 2000,
pauseOnHover: false,
});
});



jQuery( document ).ready(function($) {
$('#client').slick({
dots: false,
arrows: true,
infinite: true,
speed: 2000,
slidesToShow: 1,
loop: true,
slidesToScroll: 1,
autoplay: false,
autoplaySpeed: 2000,
pauseOnHover: false,
});
});
